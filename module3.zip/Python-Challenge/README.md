# 1 Financial Analysis
 ## Basic financial analysis in python

This challenge involves using python to analys financial records for a company which include:
- The net profit/loss at the end of the period
- The Average change in profit and loss
- The highest profit attained and higest loss attained

# 2 Poll Analysis
## Modernized vote counting in a small Rural town 

This challange involves helping a smaall rural town modernize its cote counting process, the computation includes:
- Total number of  votes
- List of candidates
- Total votes per candidate
- Percentage votes per candidates
- The winner