#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pd

# Read the CSV file
data = pd.read_csv("Resources/election_data.csv")

# Total number of votes cast
votes_cast = len(data["Ballot ID"])
print("Total Votes:", votes_cast)

# List of candidates who received votes
candidates = data["Candidate"].unique()
print("Candidates:")
print(candidates)

# Percentage votes each candidate won
votes_per = round((data["Candidate"].value_counts() / votes_cast) * 100)
print("Percentage Votes:")
for candidate in candidates:
    print(candidate, votes_per[candidate], "% Votes")

# Total votes each candidate won
votes_tot = data["Candidate"].value_counts()
print("Total Votes:")
for candidate in candidates:
    print(candidate, votes_tot[candidate], "Votes")

# Winner
winner = votes_per.idxmax()
print("Winner: " + winner + " with", votes_per[winner], "% of the votes")

