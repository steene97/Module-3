import pandas as pd

# Read the CSV file
data = pd.read_csv("C:/Users/Administrator/Documents/GitHub/Financial_Analysis/PyBank/Resources/budget_data.csv")
data.head()

# Number of months the data was collected
num_months = len(data["Date"])
print("Number of months:", num_months)

# Net profit/loss
net_profit_loss = data["Profit/Losses"].sum()
print("Net profit/loss:", net_profit_loss)

# Average change in profit/loss over the whole period
average_change = data["Profit/Losses"].diff().mean().round(3)
print("Average change in profit/loss:", average_change)

# Greatest increase in profit
max_increase = data.loc[data["Profit/Losses"].diff() == data["Profit/Losses"].diff().max()]
print("Greatest increase in profit:")
print(max_increase)

# Greatest decrease in profit
max_decrease = data.loc[data["Profit/Losses"].diff() == data["Profit/Losses"].diff().min()]
print("Greatest decrease in profit:")
print(max_decrease)

